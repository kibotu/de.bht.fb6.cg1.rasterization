package de.bht.fb6.cg1.rasterization;

/**
 * This interface is the base Interface for all figures. It's necessary to
 * handle all figures in a List.
 *
 * @author Stephan Rehfeld
 */
public interface IFigure {

}
