package de.bht.fb6.cg1.exercise4;

import java.util.HashMap;
import java.util.Map;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.glu.Sphere;

/**
 * This class creates a window with an OpenGL Context and draws a triangle in
 * it. The implementation is inspired by a lwgl example.
 * 
 * @author Stephan Rehfeld
 */
public class OpenGLMain {

    /**
     * The framerate.
     * 
     */
    private static final int FRAMERATE = 60;

    /**
     * This flag is true if the application should run. If it's set to false the
     * application will terminate.
     */
    private static boolean finished;

    /**
     * The translation of the polygon on the x-axis.
     */
    private static float x = 0.0f;

    /**
     * The translation of the polygon on the y-axis.
     */
    private static float y = 0.0f;

    /**
     * The translation of the polygon on the z-axis.
     */
    private static float z = 0.0f;

    /**
     * The rotation around the x-axis.
     */
    private static float rx = 0.0f;

    /**
     * The rotation around the y-axis.
     */
    private static float ry = 0.0f;

    /**
     * The rotation around the z-axis.
     */
    private static float rz = 0.0f;

    /**
     * upends the arm
     */
    private static float arm1 = 0f;
    private static float arm2 = 0f;
    private static float arm3 = 0f;

    /** 
     * rotates the arms
     */
    private static float armR1 = 0f;
    private static float armR2 = 0f;
    private static float armR3 = 0f;

    final public static int DISPLAY_WIDTH = 800;
    final public static int DISPLAY_HEIGHT = 600;

    /**
     * stores list ids
     */
    final private static Map<String, Integer> displayList = new HashMap<String, Integer>();

    /**
     * The main class.
     * 
     * @param args
     *            To arguments are consumed.
     */
    public static void main(final String[] args) {

	try {
	    init();
	    run();
	} catch (final Exception e) {
	    e.printStackTrace(System.err);
	} finally {
	    cleanup();
	}
	System.exit(0);
    }

    /**
     * The method creates the the window and sets up the projection matrix, the
     * viewport, and the initial model matrix.
     * 
     * @throws java.lang.Exception
     *             Is thrown on any possible error.
     */
    private static void init() throws Exception {

	Display.setTitle("Exercise 4");
	Display.setVSyncEnabled(true);

	final DisplayMode[] modes = Display.getAvailableDisplayModes();
	for (int i = 0; i < modes.length; ++i) {
	    if (modes[i].getWidth() == DISPLAY_WIDTH) {
		Display.setDisplayMode(modes[i]);
		break;
	    }
	}

	Display.create();

	setOrthView();
	// setPerspView();

	GL11.glEnable(GL11.GL_DEPTH_TEST);

	// lists
	createDisplayLists();
    }

    /**
     * This method runs the application.
     */
    private static void run() {

	while (!finished) {
	    Display.update();
	    if (Display.isCloseRequested()) {
		finished = true;
	    } else if (Display.isActive()) {
		logic();
		render();
		Display.sync(FRAMERATE);
	    } else {
		try {
		    Thread.sleep(100);
		} catch (final InterruptedException e) {
		}
		logic();
		if (Display.isVisible() || Display.isDirty()) {
		    render();
		}
	    }
	}
    }

    /**
     * The clean up is called if the application fails.
     */
    private static void cleanup() {
	Display.destroy();
    }

    /**
     * The logic of the application. Currently it processes the key input to
     * rotate the polygon.
     */
    private static void logic() {
	if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) {
	    x -= 0.01;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) {
	    x += 0.01;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_DOWN)) {
	    y -= 0.01;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_UP)) {
	    y += 0.01;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_E)) {
	    z += 0.01;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
	    z -= 0.01;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_Q)) {
	    rx += 1;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
	    rx -= 1;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
	    ry -= 1;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
	    ry += 1;
	}

	if (Keyboard.isKeyDown(Keyboard.KEY_Y)) {
	    rz -= 1;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_X)) {
	    rz += 1;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
	    finished = true;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_O)) {
	    setOrthView();
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_P)) {
	    setPerspView();
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_T)) {
	    arm1++;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_G)) {
	    arm1--;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_Z)) {
	    arm2 += 5 % 360;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_H)) {
	    arm2 -= 5 % 360;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_U)) {
	    arm3 += 5 % 360;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_J)) {
	    arm3 -= 5 % 360;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_B)) {
	    armR1++;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_N)) {
	    armR2++;
	}
	if (Keyboard.isKeyDown(Keyboard.KEY_M)) {
	    armR3++;
	}
    }

    /**
     * switches to perspective view
     */
    private static void setPerspView() {
	GL11.glMatrixMode(GL11.GL_PROJECTION);
	GL11.glLoadIdentity();
	GLU.gluPerspective(80, Display.getDisplayMode().getWidth() / Display.getDisplayMode().getHeight(), 1, 20);
	GL11.glMatrixMode(GL11.GL_MODELVIEW);
	GL11.glLoadIdentity();
	GLU.gluLookAt(0f, 0f, 5f, 0f, 0f, 0f, 0f, 1f, 0f);
    }

    /**
     * switches to orthographic view
     */
    private static void setOrthView() {
	GL11.glMatrixMode(GL11.GL_PROJECTION);
	GL11.glLoadIdentity();
	GL11.glViewport(0, 0, Display.getDisplayMode().getWidth(), Display.getDisplayMode().getHeight());
	GL11.glOrtho(-(float) Display.getDisplayMode().getWidth() / Display.getDisplayMode().getHeight(),
		(float) Display.getDisplayMode().getWidth() / Display.getDisplayMode().getHeight(), -1, 1, -1, 1);
	GL11.glMatrixMode(GL11.GL_MODELVIEW);
	GL11.glLoadIdentity();
    }

    /**
     * This method renders the image.
     * 
     * Start to make your changes here!
     */
    private static void render() {
	GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_STENCIL_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
	GL11.glCallList(displayList.get("Bottom Plane"));
	drawRoboticArm();
    }

    /**
     * draws sphere
     */
    private static void drawSphere() {
	GL11.glColor3f(0.5f, 0.5f, 0.5f);
	final Sphere s = new Sphere();
	s.draw(0.5f, 48, 48);
    }

    /**
     * creates display lists s
     */
    public static void createDisplayLists() {
	int listId = GL11.glGenLists(1);
	displayList.put("Sphere", listId);
	GL11.glNewList(listId, GL11.GL_COMPILE);
	drawSphere();
	GL11.glEndList();

	listId = GL11.glGenLists(1);
	displayList.put("Cube", listId);
	GL11.glNewList(listId, GL11.GL_COMPILE);
	drawCube();
	GL11.glEndList();

	listId = GL11.glGenLists(1);
	displayList.put("Bottom Plane", listId);
	GL11.glNewList(listId, GL11.GL_COMPILE);
	drawBottomPlane();
	GL11.glEndList();
    }

    /**
     * draws bottom plane
     */
    private static void drawBottomPlane() {
	GL11.glPushMatrix();
	GL11.glScalef(4f, 4f, 4f);
	drawRectangle(Coords.XZ);
	GL11.glPopMatrix();
    }

    /**
     * enables default rotating of the robotic arm
     */
    private static void drawRoboticArm() {
	GL11.glPushMatrix();
	GL11.glTranslatef(x, y, z);
	GL11.glRotatef(rx, 1.0f, 0.0f, 0.0f);
	GL11.glRotatef(ry, 0.0f, 1.0f, 0.0f);
	GL11.glRotatef(rz, 0.0f, 0.0f, 1.0f);
	arms();
	GL11.glPopMatrix();
    }

    /**
     * draws robotic arm
     */
    private static void arms() {
	final float width = 0.33f;
	final float deepth = 0.33f;
	final float height = 1f;
	final float radius = 0.3f;
	/* anfang 1. arm */
	GL11.glTranslatef(-width / 2, -2f, -deepth / 2);

	GL11.glPushMatrix();
	GL11.glTranslatef(width / 2, 0f, deepth / 2);
	GL11.glScalef(radius, radius, radius);
	GL11.glCallList(displayList.get("Sphere"));
	GL11.glPopMatrix();

	GL11.glTranslatef(width / 2, 0f, deepth / 2);

	GL11.glPushMatrix();
	// kippen
	GL11.glRotatef(arm1, 0f, 0f, 1f);
	// um eigene achse drehen
	GL11.glRotatef(armR1, 0.0f, 1f, 0.0f);
	GL11.glTranslatef(0f, 0.65f, 0f);
	drawCubic(width, height, deepth);
	/* anfang 2. arm * */
	GL11.glTranslatef(0f, 0.8f, 0f);

	GL11.glPushMatrix();
	GL11.glTranslatef(0f, -0.15f, 0f);
	GL11.glScalef(radius, radius, radius);
	GL11.glCallList(displayList.get("Sphere"));
	GL11.glPopMatrix();

	GL11.glPushMatrix();
	// um eigene achse drehen
	GL11.glRotatef(armR2, 0.0f, 1.0f, 0.0f);
	// kippen
	GL11.glRotatef(arm2, 0f, 0f, 1f);
	GL11.glTranslatef(0f, 0.5f, 0f);
	drawCubic(width, height, deepth);
	/* anfang 3. arm */
	GL11.glTranslatef(0f, 0.8f, 0f);

	GL11.glPushMatrix();
	GL11.glTranslatef(0f, -0.15f, 0f);
	GL11.glScalef(radius, radius, radius);
	GL11.glCallList(displayList.get("Sphere"));
	GL11.glPopMatrix();

	GL11.glPushMatrix();
	// um eigene achse drehen
	GL11.glRotatef(armR3, 0.0f, 1.0f, 0.0f);
	// kippen
	GL11.glRotatef(arm3, 0f, 0f, 1f);
	GL11.glTranslatef(0f, 0.5f, 0f);
	drawCubic(width, height, deepth);
	/* ende 3. arm */
	GL11.glPopMatrix();
	/* ende 2. arm */
	GL11.glPopMatrix();
	/* ende 1. arm */
	GL11.glPopMatrix();
    }

    /**
     * drwas
     * 
     * @param width
     * @param height
     * @param deepth
     */
    private static void drawCubic(final float width, final float height, final float deepth) {
	GL11.glPushMatrix();
	GL11.glScalef(width, height, deepth);
	GL11.glCallList(displayList.get("Cube"));
	GL11.glPopMatrix();
    }

    /**
     * draws simple 1x1x1 cube; center is in the middle of the cube
     */
    private static void drawCube() {
	// far
	drawRectangle(Coords.XY);
	// near
	GL11.glPushMatrix();
	GL11.glTranslatef(0f, 0f, 1f);
	drawRectangle(Coords.XY);
	GL11.glPopMatrix();
	// bottom
	drawRectangle(Coords.XZ);
	// top
	GL11.glPushMatrix();
	GL11.glTranslatef(0f, 1f, 0f);
	drawRectangle(Coords.XZ);
	GL11.glPopMatrix();
	// left
	drawRectangle(Coords.YZ);
	// right
	GL11.glPushMatrix();
	GL11.glTranslatef(1f, 0f, 0f);
	drawRectangle(Coords.YZ);
	GL11.glPopMatrix();
    }

    /**
     * draws rectangle on a certain coordinate system
     * 
     * @param coords
     */
    private static void drawRectangle(final Coords coords) {
	final float c = -0.5f;
	if (Coords.XY == coords) {
	    drawTriangle(c, c, c, c, c + 1, c, c + 1, c + 1, c);
	    drawTriangle(c, c, c, c + 1, c, c, c + 1, c + 1, c);
	}
	if (Coords.XZ == coords) {
	    drawTriangle(c, c, c, c, c, c + 1, c + 1, c, c + 1);
	    drawTriangle(c, c, c, c + 1, c, c, c + 1, c, c + 1);
	}
	if (Coords.YZ == coords) {
	    drawTriangle(c, c, c, c, c + 1, c, c, c + 1, c + 1);
	    drawTriangle(c, c, c, c, c, c + 1, c, c + 1, c + 1);
	}
    }

    /**
     * draws triangle
     * 
     * @param x1
     * @param y1
     * @param z1
     * @param x2
     * @param y2
     * @param z2
     * @param x3
     * @param y3
     * @param z3
     */
    private static void drawTriangle(final float x1, final float y1, final float z1, final float x2, final float y2,
	    final float z2, final float x3, final float y3, final float z3) {
	GL11.glBegin(GL11.GL_TRIANGLES);
	GL11.glColor3f(1.0f, 0.0f, 0.0f);
	GL11.glVertex3f(x1, y1, z1);
	GL11.glColor3f(0.0f, 1.0f, 0.0f);
	GL11.glVertex3f(x2, y2, z2);
	GL11.glColor3f(0.0f, 0.0f, 1.0f);
	GL11.glVertex3f(x3, y3, z3);
	GL11.glEnd();
    }

}