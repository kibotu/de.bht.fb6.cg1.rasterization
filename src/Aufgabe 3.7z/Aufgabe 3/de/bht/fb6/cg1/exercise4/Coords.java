package de.bht.fb6.cg1.exercise4;

public enum Coords {

    XZ("xy"), XY("xy"), YZ("yz");

    private final String name;

    private Coords(String name) {
	this.name = name;
    }

    @Override
    public String toString() {
	return name;
    }
    
}